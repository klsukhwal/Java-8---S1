package mypackage;

import java.util.Random;

public class TestMedicine {
    public static void main(String[] args) {
        // Declare an array of Medicine references of size 10
        MedicineInfo[] medicines = new MedicineInfo[10];

        // Create a medicine object of the type as decided by a randomly generated integer
        Random random = new Random();
        for (int i = 0; i < 10; i++) {
            int randomMedicineType = random.nextInt(3) + 1;

            switch (randomMedicineType) {
                case 1:
                    medicines[i] = new Tablet("Paracetamol", "ABC Pharmaceuticals");
                    break;
                case 2:
                    medicines[i] = new Syrup("CoughEx", "XYZ Pharmaceuticals");
                    break;
                case 3:
                    medicines[i] = new Ointment("HealFast", "PQR Pharmaceuticals");
                    break;
            }
        }

        // Check the polymorphic behavior of the displayLabel() method
        for (MedicineInfo medicine : medicines) {
            if (medicine != null) {
                medicine.displayLabel();
                System.out.println("------------------------");
            }
        }
    }
}
