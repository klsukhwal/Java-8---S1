package mypackage;

public class Book {
    private String bookTitle;
    private double bookPrice;

    // Constructors
    public Book() {
        this.bookTitle = "";
        this.bookPrice = 0.0;
    }

    public Book(String bookTitle, double bookPrice) {
        this.bookTitle = bookTitle;
        this.bookPrice = bookPrice;
    }

    // Getter and Setter methods
    public String getBookTitle() {
        return this.bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public double getBookPrice() {
        return this.bookPrice;
    }

    public void setBookPrice(double bookPrice) {
        this.bookPrice = bookPrice;
    }

    // Pure functions
    public static Book[] createBooks(int n) {
        Book[] books = new Book[n];

        for (int i = 0; i < n; i++) {
            books[i] = createBookFromUserInput();
        }

        return books;
    }

    public static void showBooks(Book[] books) {
        System.out.println("Book Title\tPrice");

        for (Book book : books) {
            System.out.println(book.getBookTitle() + "\t\tRs " + book.getBookPrice());
        }
    }

    private static Book createBookFromUserInput() {
        // Function to create a book from user input
        // You can customize this based on your requirements
        // For simplicity, assuming title and price are provided by the user

        // Note: In a real application, you might want to add input validation and error handling

        String title = ""; // You can replace with actual input
        double price = 10.0; // You can replace with actual input

        return new Book(title, price);
    }
}
