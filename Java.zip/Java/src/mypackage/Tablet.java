package mypackage;

class Tablet implements MedicineInfo {
    private String name;
    private String address;

    // Constructor for Tablet
    public Tablet(String name, String address) {
        this.name = name;
        this.address = address;
    }

    @Override
    public void displayLabel() {
        System.out.println("Tablet: " + name + "\nStore in a cool, dry place\nManufactured by: " + address);
    }
}
