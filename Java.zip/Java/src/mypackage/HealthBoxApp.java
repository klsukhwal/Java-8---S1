package mypackage;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class HealthBoxApp {
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
    private static final Map<Integer, HealthBoxAppointment> appointments = new HashMap<>();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        int option;
        do {
            displayMenu();
            System.out.print("Enter an Option: ");
            option = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            switch (option) {
                case 1:
                    scheduleAppointment();
                    break;
                case 2:
                    printAppointmentDetails();
                    break;
                case 3:
                    rescheduleAppointment();
                    break;
                case 4:
                    getReminder();
                    break;
                case 5:
                    cancelAppointment();
                    break;
                case 6:
                    System.out.println("Exiting the HealthBox App. Thank you!");
                    break;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        } while (option != 6);
    }

    private static void displayMenu() {
        System.out.println("1. Schedule an Appointment");
        System.out.println("2. Print Appointment Details");
        System.out.println("3. Reschedule an Appointment");
        System.out.println("4. Get Reminder");
        System.out.println("5. Cancel the Appointments");
        System.out.println("6. Exit");
        System.out.println("================================");
    }

    private static void scheduleAppointment() {
        System.out.println("Enter Date (dd/MM/yyyy): ");
        String dateStr = scanner.nextLine();
        System.out.println("Enter Time (HH:mm): ");
        String timeStr = scanner.nextLine();
        System.out.println("Available Zones are:");
        System.out.println("A: America/Anchorage");
        System.out.println("B: Europe/Paris");
        System.out.println("C: Asia/Tokyo");
        System.out.println("D: America/Phoenix");
        System.out.println("Select the Zone:");
        String zone = scanner.nextLine();

        LocalDateTime dateTime = LocalDateTime.parse(dateStr + " " + timeStr, formatter);
        HealthBoxAppointment appointment = new HealthBoxAppointment(dateTime, zone);

        appointments.put(appointments.size() + 1, appointment);
        System.out.println("Successfully Booked!");
    }

    private static void printAppointmentDetails() {
        System.out.println("Enter an Option: ");
        int option = scanner.nextInt();
        if (appointments.containsKey(option)) {
            HealthBoxAppointment appointment = appointments.get(option);
            System.out.println(formatter.format(appointment.dateTime) + " " + appointment.zone);
        } else {
            System.out.println("Appointment not booked. Please book an appointment first.");
        }
    }

    private static void rescheduleAppointment() {
        System.out.println("Enter an Option: ");
        int option = scanner.nextInt();
        if (appointments.containsKey(option)) {
            HealthBoxAppointment appointment = appointments.get(option);
            System.out.println("Current Appointment Date is: ");
            System.out.println(formatter.format(appointment.dateTime) + " " + appointment.zone);

            System.out.println("Kindly Enter Number of Days to be postponed: ");
            int days = scanner.nextInt();
            System.out.println("Enter the new time in HH:mm: ");
            String timeStr = scanner.next();

            LocalDateTime newDateTime = appointment.dateTime.plusDays(days).withHour(Integer.parseInt(timeStr.split(":")[0]))
                    .withMinute(Integer.parseInt(timeStr.split(":")[1]));
            HealthBoxAppointment newAppointment = new HealthBoxAppointment(newDateTime, appointment.zone);

            appointments.put(option, newAppointment);
            System.out.println("Your Appointment has been rescheduled to: ");
            System.out.println(formatter.format(newAppointment.dateTime) + " " + newAppointment.zone);
        } else {
            System.out.println("Appointment not booked. Please book an appointment first.");
        }
    }

    private static void getReminder() {
        System.out.println("Enter an Option: ");
        int option = scanner.nextInt();
        if (appointments.containsKey(option)) {
            HealthBoxAppointment appointment = appointments.get(option);
            LocalDateTime reminderDateTime = appointment.dateTime.minusDays(1);

            System.out.println("Reminder: Your Appointment is scheduled on " + formatter.format(reminderDateTime) +
                    " " + appointment.zone);
        } else {
            System.out.println("Appointment not booked. Please book an appointment first.");
        }
    }

    private static void cancelAppointment() {
        System.out.println("Enter an Option: ");
        int option = scanner.nextInt();
        if (appointments.containsKey(option)) {
            appointments.remove(option);
            System.out.println("Appointment has been cancelled!!");
        } else {
            System.out.println("Appointment not booked. Please book an appointment first.");
        }
    }
}