package mypackage;

public class TestDecoratorPattern {
    public static void main(String[] args) {
        // Create a base burger
        Burger baseBurger = new Burger("burger");

        // Create a BurgerShop with the decoration functions
        BurgerShop burgerShop = new BurgerShop(burger -> burger.addVeggies().addCheese());

        // Place an order with a burger base and add veggies and cheese to it
        Burger decoratedBurger = burgerShop.use(baseBurger);

        // Display the final burger
        System.out.println("Final Burger: " + decoratedBurger);
    }
}