package mypackage;

interface Instrument {
    void play();
}

