package mypackage;

import java.util.ArrayList;
import java.util.List;

public class TestStockFilters {
    public static void main(String[] args) {
        List<Stock> stocks = new ArrayList<>();
        stocks.add(new Stock("AAPL", 318.65, 10.0));
        stocks.add(new Stock("MSFT", 166.86, 45.0));
        stocks.add(new Stock("Google", 99.0, 12.5));
        stocks.add(new Stock("AMZ", 1866.74, 45.0));
        stocks.add(new Stock("GOOGL", 1480.2, 3.5));
        stocks.add(new Stock("AAPL", 318.65, 8.0));
        stocks.add(new Stock("AMZ", 1866.74, 9.0));

        // 1. Print all the stocks details using forEach and Method Reference
        System.out.println("--Print all the Stock Details--");
        stocks.forEach(System.out::println);

        // 2. Print all the stocks details whose symbol is AMZ
        System.out.println("-Symbol is equals to AMZ-");
        List<Stock> amzStocks = StockFilters.filter(stocks, stock -> stock.getSymbol().equals("AMZ"));
        amzStocks.forEach(System.out::println);

        // 3. Print all the stocks details whose price is above 300
        System.out.println("-Price is above 300-");
        List<Stock> highPriceStocks = StockFilters.filter(stocks, stock -> stock.getPrice() > 300);
        highPriceStocks.forEach(System.out::println);
    }
}
