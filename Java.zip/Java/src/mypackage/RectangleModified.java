package mypackage;

public class RectangleModified {
    private double length = 1;
    private double width = 1;

    // Pure member functions
    public double calculatePerimeter() {
        return 2 * (this.length + this.width);
    }

    public double calculateArea() {
        return this.length * this.width;
    }

    // Set and Get functions with validation
    public double getLength() {
        return this.length;
    }

    public void setLength(double length) {
        if (isValidDimension(length)) {
            this.length = length;
        }
    }

    public double getWidth() {
        return this.width;
    }

    public void setWidth(double width) {
        if (isValidDimension(width)) {
            this.width = width;
        }
    }

    // Validation function
    private boolean isValidDimension(double dimension) {
        return dimension > 0.0 && dimension < 20.0;
    }
}
