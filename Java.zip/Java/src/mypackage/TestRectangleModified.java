package mypackage;

public class TestRectangleModified {
    public static void main(String[] args) {
        // Example usage

        // Step 1: Create a RectangleModified object with default dimensions
        RectangleModified rectangle = new RectangleModified();

        // Step 2: Display default dimensions, perimeter, and area
        System.out.println("Default Length: " + rectangle.getLength());
        System.out.println("Default Width: " + rectangle.getWidth());
        System.out.println("Perimeter: " + rectangle.calculatePerimeter());
        System.out.println("Area: " + rectangle.calculateArea());

        // Step 3: Set new dimensions and display updated information
        rectangle.setLength(5.0);
        rectangle.setWidth(3.0);

        System.out.println("\nUpdated Length: " + rectangle.getLength());
        System.out.println("Updated Width: " + rectangle.getWidth());
        System.out.println("Perimeter: " + rectangle.calculatePerimeter());
        System.out.println("Area: " + rectangle.calculateArea());
    }
}
