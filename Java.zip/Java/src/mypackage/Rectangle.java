package mypackage;

public class Rectangle {
    private double length;
    private double breadth;

    // Constructors
    public Rectangle() {
        this.length = 0;
        this.breadth = 0;
    }

    public Rectangle(double length, double breadth) {
        this.length = length;
        this.breadth = breadth;
    }

    // Accessor & Mutator methods
    public double getLength() {
        return this.length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    public double getBreadth() {
        return this.breadth;
    }

    public void setBreadth(double breadth) {
        this.breadth = breadth;
    }

    // Pure functions
    public double calculateArea() {
        return this.length * this.breadth;
    }

    public void displayInfo() {
        System.out.println("Length: " + this.length + ", Breadth: " + this.breadth + ", Area: " + calculateArea());
    }
}
