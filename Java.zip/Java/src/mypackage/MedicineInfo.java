package mypackage;

interface MedicineInfo {
    void displayLabel();
}
