package mypackage;

public class TestBook {
    public static void main(String[] args) {
        // Example usage

        // Step 1: Create an array of books
        int numberOfBooks = 2; // You can change the number of books as needed
        Book[] books = Book.createBooks(numberOfBooks);

        // Step 2: Display the books
        Book.showBooks(books);
    }
}
