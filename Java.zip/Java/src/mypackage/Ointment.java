package mypackage;

class Ointment implements MedicineInfo {
    private String name;
    private String address;

    // Constructor for Ointment
    public Ointment(String name, String address) {
        this.name = name;
        this.address = address;
    }

    @Override
    public void displayLabel() {
        System.out.println("Ointment: " + name + "\nFor external use only\nManufactured by: " + address);
    }
}
