package mypackage;

public class TestInstruments {
    public static void main(String[] args) {
        // Create an array of 10 Instruments
        Instrument[] instruments = new Instrument[10];

        // Assign different types of instruments to Instrument references using Lambda Expressions
        instruments[0] = () -> System.out.println("Piano is playing tan tan tan tan");
        instruments[1] = () -> System.out.println("Flute is playing toot toot toot toot");
        instruments[2] = () -> System.out.println("Guitar is playing tin tin tin");

        // Check for polymorphic behavior of play method
        for (int i = 0; i < 3; i++) {
            if (instruments[i] != null) {
                instruments[i].play();
                // Use instanceof operator to print the type of instrument
                if (instruments[i] instanceof Instrument) {
                    System.out.println("Instrument at index " + i + " is a generic Instrument");
                }
            }
        }
    }
}
