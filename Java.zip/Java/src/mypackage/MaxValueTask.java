package mypackage;

import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.RecursiveTask;

public class MaxValueTask extends RecursiveTask<Integer> {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private static final int THRESHOLD = 1000; // Add THRESHOLD here
    private int[] array;
    private int start;
    private int end;

    public MaxValueTask(int[] array, int start, int end) {
        this.array = array;
        this.start = start;
        this.end = end;
    }

    @Override
    protected Integer compute() {
        if (end - start <= THRESHOLD) {
            int max = Integer.MIN_VALUE;
            for (int i = start; i < end; i++) {
                max = Math.max(max, array[i]);
            }
            System.out.println("Max value found: " + max + ", range: " + start + "-" + end);
            return max;
        } else {
            int mid = (start + end) / 2;
            MaxValueTask leftTask = new MaxValueTask(array, start, mid);
            MaxValueTask rightTask = new MaxValueTask(array, mid, end);

            invokeAll(leftTask, rightTask);

            int leftMax = leftTask.join();
            int rightMax = rightTask.join();

            int result = Math.max(leftMax, rightMax);
            System.out.println("Subtask result: " + result + ", range: " + start + "-" + end);
            return result;
        }
    }

    public static void main(String[] args) {
        int[] array = new int[10000];
        for (int i = 0; i < 10000; i++) {
            array[i] = i;
        }

        ForkJoinPool forkJoinPool = new ForkJoinPool();
        MaxValueTask task = new MaxValueTask(array, 0, array.length);

        int result = forkJoinPool.invoke(task);

        System.out.println("Max value of the array: " + result);
    }
}

