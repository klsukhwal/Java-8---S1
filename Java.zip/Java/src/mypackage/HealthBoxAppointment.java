package mypackage;

import java.time.LocalDateTime;

class HealthBoxAppointment {
    LocalDateTime dateTime;
    String zone;

    public HealthBoxAppointment(LocalDateTime dateTime, String zone) {
        this.dateTime = dateTime;
        this.zone = zone;
    }
}


