package mypackage;

import java.util.Comparator;
import java.util.HashSet;
import java.util.IntSummaryStatistics;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class TestPersonDetails {

    public static void main(String[] args) {
        Set<Person> personSet = createPersonSet();

        // 1. Print all the persons details using the Streams and Method Reference features
        System.out.println("--Print all the person records--");
        personSet.forEach(System.out::println);

        // 2. Print all the persons details by sorting the id in ascending order using Comparator and Streams
        System.out.println("--Sorted Asc by Id--");
        personSet.stream()
                .sorted(Comparator.comparingInt(Person::getId))
                .forEach(System.out::println);

        // 3. Print all the persons details by sorting the name in ascending order using Comparator and Streams
        System.out.println("--Sorted Asc by Name--");
        personSet.stream()
                .sorted(Comparator.comparing(Person::getName))
                .forEach(System.out::println);

        // 4. Print all the persons details by sorting the names in descending order using Comparator and Streams
        System.out.println("--Sorted Desc by Name--");
        personSet.stream()
                .sorted(Comparator.comparing(Person::getName).reversed())
                .forEach(System.out::println);

        // 5. Print all the persons details whose Name start with J using Streams
        System.out.println("--Name start with J--");
        personSet.stream()
                .filter(person -> person.getName().startsWith("J"))
                .forEach(System.out::println);

        // 6. Print the count number of persons using Streams
        System.out.println("--Count number of persons--");
        long count = personSet.stream().count();
        System.out.println("Count: " + count);

        // 7. Print the Max salary among all persons using Streams
        System.out.println("--Max salary among all persons--");
        personSet.stream()
                .mapToDouble(Person::getSalary)
                .max()
                .ifPresent(System.out::println);

        // 8. Print the Min salary among all persons using Streams
        System.out.println("--Min salary among all persons--");
        personSet.stream()
                .mapToDouble(Person::getSalary)
                .min()
                .ifPresent(System.out::println);

        // 9. Print the average of all salaries using Streams
        System.out.println("--Average of salaries--");
        personSet.stream()
                .mapToDouble(Person::getSalary)
                .average()
                .ifPresent(System.out::println);

        // 10. Print the sum of all salaries using Streams
        System.out.println("--Sum of all salaries--");
        double sum = personSet.stream()
                .mapToDouble(Person::getSalary)
                .sum();
        System.out.println("Sum: " + sum);

        // 11. Print the First Person whose Name start with J using Streams - filter and findFirst method
        System.out.println("--First Person whose Name start with J--");
        personSet.stream()
                .filter(person -> person.getName().startsWith("J"))
                .findFirst()
                .ifPresent(System.out::println);

        // 12. Check whether all the persons age is greater than 10 using Streams - allMatch method
        System.out.println("--Return true if All person age greater than 10--");
        boolean allMatch = personSet.stream()
                .allMatch(person -> person.getAge() > 10);
        System.out.println(allMatch);

        // 13. Check whether all the persons age is greater than 50 using Streams - noneMatch method
        System.out.println("--Return true if All person age greater than 50--");
        boolean noneMatch = personSet.stream()
                .noneMatch(person -> person.getAge() > 50);
        System.out.println(noneMatch);

        // 14. Group By Salary using Collectors.groupingBy
        System.out.println("--Group By Salary--");
        Map<Double, List<Person>> groupedBySalary = personSet.stream()
                .collect(Collectors.groupingBy(Person::getSalary));
        groupedBySalary.forEach((key, value) -> {
            System.out.println("Person Grouped By: " + key);
            value.forEach(System.out::println);
        });

        // 15. Print the average of all salaries using Streams and Collectors
        System.out.println("--Average of salaries--");
        double averageSalary = personSet.stream()
                .collect(Collectors.averagingDouble(Person::getSalary));
        System.out.println(averageSalary);

        // 16. Print all the persons details group by salary using Streams and Collectors
        System.out.println("--Group By Salary and Print--");
        Map<Double, List<Person>> groupedBySalaryMap = personSet.stream()
                .collect(Collectors.groupingBy(Person::getSalary));
        groupedBySalaryMap.forEach((key, value) -> {
            System.out.println("Salary: " + key);
            value.forEach(System.out::println);
        });

        // 17. Print all the names after joining whose age is greater than 18 using Streams and Collectors
        System.out.println("--Joining all the names whose age is greater than 18--");
        String result = personSet.stream()
                .filter(person -> person.getAge() > 18)
                .map(Person::getName)
                .collect(Collectors.joining(" and ", "In Germany ", " are of legal age."));
        System.out.println(result);

        // 18. Print the Min, Max, Count, Average and Sum of all persons using IntSummaryStatistics and Collectors
        System.out.println("--Statistics object--");
        IntSummaryStatistics ageStatistics = personSet.stream()
                .collect(Collectors.summarizingInt(Person::getAge));
        System.out.println(ageStatistics);

        // 19. Determine the oldest person among all using Streams and Reduce
        System.out.println("--Determine the oldest person--");
        personSet.stream()
                .reduce((p1, p2) -> p1.getAge() > p2.getAge() ? p1 : p2)
                .ifPresent(System.out::println);

        // 20. Add n number of multiple records and print the time take with sequential using stream
        System.out.println("--Performing Sequentially--");
        long sequentialStartTime = System.currentTimeMillis();
        createMultiplePersons(1000000);
        long sequentialEndTime = System.currentTimeMillis();
        System.out.println("Time taken with Sequential: " + (sequentialEndTime - sequentialStartTime));

        // 21. Print the time taken with parallel using parallelStream
        System.out.println("--Performing parallely--");
        long parallelStartTime = System.currentTimeMillis();
        createMultiplePersons(1000000).parallelStream().collect(Collectors.toSet());
        long parallelEndTime = System.currentTimeMillis();
        System.out.println("Time taken with parallel : " + (parallelEndTime - parallelStartTime));
    }

    private static Set<Person> createPersonSet() {
        Set<Person> personSet = new HashSet<>();
        personSet.add(new Person(1, "Jerry", 12, 999.0));
        personSet.add(new Person(2, "Smith", 22, 2999.0));
        personSet.add(new Person(3, "Popeye", 21, 5999.0));
        personSet.add(new Person(4, "Jones", 22, 6999.0));
        personSet.add(new Person(5, "John", 32, 1999.0));
        personSet.add(new Person(6, "Tom", 42, 3999.0));
        return personSet;
    }

    private static Set<Person> createMultiplePersons(int n) {
        Set<Person> personSet = new HashSet<>();
        for (int i = 7; i <= n + 6; i++) {
            personSet.add(new Person(i, "Person" + i, 25, i * 1000.0));
        }
        return personSet;
    }
}
