package mypackage;

class Syrup implements MedicineInfo {
    private String name;
    private String address;

    // Constructor for Syrup
    public Syrup(String name, String address) {
        this.name = name;
        this.address = address;
    }

    @Override
    public void displayLabel() {
        System.out.println("Syrup: " + name + "\nShake well before use\nManufactured by: " + address);
    }
}
