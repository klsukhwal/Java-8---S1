package mypackage;

public class TestCalculator {
    public static void main(String[] args) {
        Calculator calculator = new Calculator();

        // Use Lambda Expressions with multiple parameters to implement IntegerMath interface
        IntegerMath addition = (a, b) -> a + b;
        IntegerMath subtraction = (a, b) -> a - b;
        IntegerMath multiplication = (a, b) -> a * b;
        IntegerMath division = (a, b) -> (b != 0) ? a / b : 0;

        // Using behavior parameterization, override the operation method in each of these classes
        // Print information appropriate to the type of operation
        System.out.println("Addition is: " + calculator.operationBinary(20, 10, addition));
        System.out.println("Subtraction is: " + calculator.operationBinary(20, 10, subtraction));
        System.out.println("Multiplication is: " + calculator.operationBinary(20, 10, multiplication));
        System.out.println("Division is: " + calculator.operationBinary(20, 10, division));
    }
}
