package mypackage;

public interface IntegerMath {
    int operation(int a, int b);
}
