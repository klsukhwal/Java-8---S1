package mypackage;

import java.util.function.Consumer;

public class MobileBuilder {
    int ram, storage, battery, camera;
    String processor;
    double screenSize;

    public MobileBuilder with(Consumer<MobileBuilder> buildFields) {
        buildFields.accept(this);
        return this;
    }

    public Mobile createMobile() {
        return new Mobile(this);
    }

    public static void main(String[] args) {
        // Create a mobile using builder pattern
        Mobile mobile = new MobileBuilder()
                .with(builder -> {
                    builder.ram = 4;
                    builder.storage = 64;
                    builder.battery = 4000;
                    builder.camera = 12;
                    builder.processor = "A12 Bionic";
                    builder.screenSize = 6.0;
                })
                .createMobile();

        // Display mobile specifications
        System.out.println("Specifications - ");
        System.out.println("RAM: " + mobile.ram);
        System.out.println("Storage: " + mobile.storage);
        System.out.println("Battery: " + mobile.battery);
        System.out.println("Camera: " + mobile.camera);
        System.out.println("Processor: " + mobile.processor);
        System.out.println("Screen Size: " + mobile.screenSize);
    }
}